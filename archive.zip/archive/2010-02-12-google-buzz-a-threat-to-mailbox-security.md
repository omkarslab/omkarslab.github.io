---
id: 105
title: 'Google Buzz: A threat to mailbox security?'
date: 2010-02-12T16:15:20+00:00
author: Omkar
excerpt: This is how Google Buzz can be made a completely secure Social Networking tool even though it resides inside your very private Mailbox!
layout: post
guid: http://omkarslab.co.cc/?p=105
permalink: /2010/02/12/google-buzz-a-threat-to-mailbox-security/
sfw_comment_form_password:
  - gx3NH2LWPUJU
sfw_pwd:
  - 8wMROjdEZsbI
categories:
  - Security
  - Social Networking
  - Web Reviews
tags:
  - buzz
  - contacts
  - edit
  - followers
  - gmail
  - Google
  - profile
  - secure
---
A couple days back we were introduced to the new social networking tool from Google that runs in Gmail. The new service that made quite a buzz is also known as &#8220;Buzz&#8221;.

.
  
<img class="aligncenter" title="Google Buzz" src="http://lh5.ggpht.com/_Tf3uLIahhCQ/S3V9qzQIa7I/AAAAAAAAAj0/58h-CgRBJXE/s800/buzz.jpg" alt="Google Buzz Logo" width="570" height="194" />

Google&#8217;s new Gmail Buzz enables users to follow frequently emailed contacts and keep track of their status messages and activities on various other websites like Twitter, Youtube, Google reader and many more&#8230; and this exactly what freaked out many users around the globe. &#8220;A SNW service inside your mailbox?&#8221;, well most of consider the mailbox the most private web-based service and all of a sudden people are amazed to see a new Social networking tool placed right in there.

The main concern lies in publicly displaying followers, and the people you follow on your &#8220;Google Profile&#8221;. But this can be easily turned of bu going to Google Account settings > [Edit Profile](http://www.google.com/profiles/me/editprofile) Just remove the check beside &#8220;Display the list of people I&#8217;m following and people following me&#8221;. This simple step relieves you of the risk of displaying your contacts in public.

Though this issue might not sound significant to all, there are people who would not like that to happen. While, for the few who are worried about their email data, there is no risk factor involved. Buzz is a great tool and can help u get connected to your friends and their activities on multiple websites. We live in the age of Open Communication where catching hold of an old pal is as easy ringing the neighbours doorbell&#8230; actually, for a second thought its easier than that. But the point is, that at this pace we have to adapt to the changes in the conventional way of communication, rather than become paranoid about the changes.

Check Google Buzz at <a href="http://buzz.google.com" target="_blank">http://buzz.google.com</a>