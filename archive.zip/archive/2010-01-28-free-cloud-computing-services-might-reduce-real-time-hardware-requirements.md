---
id: 33
title: Free cloud computing services might reduce real time hardware requirements
date: 2010-01-28T14:10:04+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=33
permalink: /2010/01/28/free-cloud-computing-services-might-reduce-real-time-hardware-requirements/
sfw_comment_form_password:
  - ffkw76w0zI1g
sfw_pwd:
  - 4h6X33W1jvGb
categories:
  - Uncategorized
tags:
  - Cloud
  - Computing
  - Disk space
  - Free
  - G.ho.st
  - Ghost
  - Virtual Computer
---
The latest trend in web hosting and Internet services industry is the &#8220;Cloud Computing&#8221; technology. Most of the major ISP&#8217;s are running around try to enlist cloud computing as their product service. Microsoft has already developed the Azure platform which will be releasing soon, which is basically a cloud computing platform running on Microsoft technologies.

Here&#8217;s a great service that can be a good hands experience for beginners for understanding the basic concept of cloud computing (_P.S: This might not be a pure form of cloud computing, but a good introduction to the upcoming technology_). http://g.ho.st provides a free 15GB diskspace and a cool looking desktop with some preloaded applications.

<p style="text-align: center;">
  <img class="caption" src="http://omkarkhair.co.cc/images/stories/ghost1_110909.png" border="0" title="The G.ho.st Interface provides a cool looking desktop" />
</p></p> 

  * The service also provides a yourname@g.ho.st Email ID with free POP access.
  * A synch tool to synchronize your web disk with your local disk
  * Read, Write and Edit documents, spreadsheets and presentations using Zoho tools, Google Docs amd even MS Office if available on the local drive.
  * Play MP3 music and edit photos with a variety of pre-installed apps.
  * Sharing and Collaborative tools available. You can side-load files from a torrent to your virtual computer on G.ho.st
  * Here comes the best. Access your G.ho.st drive from any internet enabled mobile at http://g.ho.st/m

<div>
  What more do you need? get your G.ho.st drive now! Click on the link below to get your G.ho.st Computer&#8230;
</div>

<p style="text-align: center;">
  <img src="http://counters.gigya.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEyNTI3NjMzNzkyMDMmcHQ9MTI1Mjc2MzM5Mzk4NCZwPTQ3NzIyMSZkPSZnPTImbz1lNDQ3ZDU*ZmI*N2I*MWQyOTQ*Zjg*ZWVmYWIyODE*NyZvZj*w.gif" border="0" width="0" height="0" /><a href="http://G.ho.st?referral=omkarkhair" target="_blank"><img src="http://cdn.g.ho.st/vcweb/pages/sharePublish/Images/spread3.png" border="0" width="130" height="131" /></a>
</p>

<p style="text-align: center;">
  G.ho.st Virtual Computer
</p></p>