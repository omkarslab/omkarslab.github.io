---
id: 79
title: 'Play To : Windows 7 (India) Web session'
date: 2010-01-28T14:27:17+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=79
permalink: /2010/01/28/play-to-windows-7-india-web-session/
sfw_comment_form_password:
  - ktduxCcLmM1b
sfw_pwd:
  - hJyXZHsFYrly
categories:
  - Uncategorized
tags:
  - Features
  - Microsoft
  - Play To
  - Security
  - Support
  - Themes
  - Windows
  - Windows 7
---
We have covered the web session in India for the Windows 7 launch. This session covered most of the new features that the brand new version of Windows 7 includes. All the questions that were covered in this session are pasted below. (Answered by Abhishek Kant)

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: what is security essential for Win 7?
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: FREE antivirus from MS..
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: does IE8 come preinstalled with Win7?
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: yes
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: When XP support will End meaning we should migrate to win 7?
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: please forward this q to contest@merawindows.com
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: Is any external antivirus required for windows7
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: antivirus is recommended.
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: Windows command prompt was not supporting Indic in XP and Vista. What abt Win7?
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: no
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: is win 7 a good developer machine&#8230;becoz vista was nt as gud as xp for developers to work with&#8230;Will command promt run in full screen &#8230;(For Turbo C++)?
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: powershell..
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: there is no audio..is there a problem?
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: audio&#8217;s fine
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: What we need to get touch-sensititive screen on Windows 7?
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: hardware device..
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: as windows XP have a good record in market for more than 9 years and still people prefer it becoz its best, success os and easy to use, so wht abt windows7 will it break record
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: we hope so..
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Question: sir, i would like to know if the windows 7 students offer is available to students in india&#8230; www.win741.com
</div>

<div id="_mcePaste" style="overflow: hidden; position: absolute; left: -10000px; top: 0px; width: 1px; height: 1px;">
  Answer: not yet.
</div>

<address>
  &#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8211;
</address>

<address>
  Question: what is security essential for Win 7?
</address>

<address>
  Answer: FREE antivirus from MS..
</address>

<address>
  Question: does IE8 come preinstalled with Win7?
</address>

<address>
  Answer: yes
</address>

<address>
  Question: When XP support will End meaning we should migrate to win 7?
</address>

<address>
  Answer: please forward this q to contest@merawindows.com
</address>

<address>
  Question: Is any external antivirus required for windows7
</address>

<address>
  Answer: antivirus is recommended.
</address>

<address>
  Question: Windows command prompt was not supporting Indic in XP and Vista. What abt Win7?
</address>

<address>
  Answer: no
</address>

<address>
  Question: is win 7 a good developer machine&#8230;becoz vista was nt as gud as xp for developers to work with&#8230;Will command promt run in full screen &#8230;(For Turbo C++)?
</address>

<address>
  Answer: powershell..
</address>

<address>
  Question: there is no audio..is there a problem?
</address>

<address>
  Answer: audio&#8217;s fine
</address>

<address>
  Question: What we need to get touch-sensititive screen on Windows 7?
</address>

<address>
  Answer: hardware device..
</address>

<address>
  Question: as windows XP have a good record in market for more than 9 years and still people prefer it becoz its best, success os and easy to use, so wht abt windows7 will it break record
</address>

<address>
  Answer: we hope so..
</address>

<address>
  Question: sir, i would like to know if the windows 7 students offer is available to students in india&#8230; www.win741.com
</address>

<address>
  Answer: not yet.
</address>

<address>
  &#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8212;&#8211;
</address>

<div>
  And as the name suggests, the latest feature &#8220;Play To&#8221; was demonstrated on the video. Play To basically enables users to stream media onto a connected/supported media device for playing it directly with a few clicks.
</div>

<div>
  Again I am sharing some slides presented at the session. As noticed from the question answers session, Windows 7 provides a free Anti-virus from Microsoft, here are a few more security enhancements.
</div>

<div style="text-align: center; ">
  <img src="http://lh6.ggpht.com/_Tf3uLIahhCQ/SuGSkfP_PgI/AAAAAAAAAYI/LeqQvNrowoU/s800/SGPhoto_2009_10_23%2016_53_25.jpg" border="0" title="Security Enhancements" width="600" height="454" />
</div>

<div style="text-align: left; ">
  Windows 7 Theme pack includes special themes for India, with Hindi support.
</div>

<div style="text-align: center; ">
  <img src="http://lh3.ggpht.com/_Tf3uLIahhCQ/SuGSmFnFqJI/AAAAAAAAAYM/YMSvPWgCs4E/s800/SGPhoto_2009_10_23%2016_53_41.jpg" border="0" title="Windows 7 Theme pack" width="600" height="421" />
</div>

<div style="text-align: left; ">
  New Features (Already covered in article 77 Windows 7 tips)
</div>

<div style="text-align: center; ">
  <img src="http://lh6.ggpht.com/_Tf3uLIahhCQ/SuGSowC5ZdI/AAAAAAAAAYQ/1hnx0EA4kFI/s800/SGPhoto_2009_10_23%2016_53_56.jpg" border="0" title="New Features : Windows 7" width="600" height="505" />
</div>

<div style="text-align: left; ">
  Microsoft Answers was launched yesterday to provide live support to Windows and Microsoft product users.
</div>

<div style="text-align: center;">
  <img src="http://lh3.ggpht.com/_Tf3uLIahhCQ/SuGSqzfaNnI/AAAAAAAAAYU/EK8QMxJZrzk/s800/SGPhoto_2009_10_23%2016_54_11.jpg" border="0" title="icrosoft Answers to provide support to Windows 7 users" width="600" height="372" />
</div>

<div style="text-align: left; ">
  For Indian residents, Windows 7 launch party details in some cities.
</div>

<div style="text-align: left; ">
  <img src="http://lh6.ggpht.com/_Tf3uLIahhCQ/SuGSsNbosAI/AAAAAAAAAYY/plSFmvHHeQI/s800/SGPhoto_2009_10_23%2016_54_23.jpg" border="0" title="Windows 7 Launch parties (India)" width="596" height="450" />
</div>

<div style="text-align: left; ">
  The recorded websession will be published at <a href="http://www.microsoft.com/india/webcasts" target="_blank">http://www.microsoft.com/india/webcasts</a>
</div></p>