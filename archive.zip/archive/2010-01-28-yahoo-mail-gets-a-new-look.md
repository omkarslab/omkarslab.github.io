---
id: 26
title: Yahoo! Mail gets a new look
date: 2010-01-28T14:06:31+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=26
permalink: /2010/01/28/yahoo-mail-gets-a-new-look/
sfw_comment_form_password:
  - DsU7pOkFBYuP
sfw_pwd:
  - kZ0H5BQ227R2
categories:
  - Uncategorized
tags:
  - AJAX
  - Email
  - Mail
  - Yahoo
---
Yahoo! is again in the news after launching its micro-blogging service MEME.

Yahoo! has changed its Email User Interface in mid 2007. This was a heavy AJAX user interface, due to which most users prefered to stick back to the Classic UI. Later, Yahoo! made significant changes later to reduce it&#8217;s loading time.

To day I see a new look to the Yahoo! Mail service. I assure you this is faster and better than the older version. The interface is extremely light and takes considerably less time to load. The look is not all that has changed in Yahoo!&#8217;s most popular service. There some new additions like the external applications connected to the mailbox. These applications include Big Sender, Photo editiors and the previously included Notepad.

The new look to the Yahoo! Mail UI seems really freash. The basic placement of ads and Email controls remains the same.

<img class="caption" src="http://omkarkhair.co.cc/images/stories/yahoo_mail_100909.png" border="0" title="Yahoo! Mail gets a Fresh new Look!" /></p> 

Yahoo! Mail currently holds about 280million users making it the worlds largest Webased mail service. Hopefully Yahoo!&#8217;s users will enjoy the new user interface and continue to contribute towards its success. 🙂