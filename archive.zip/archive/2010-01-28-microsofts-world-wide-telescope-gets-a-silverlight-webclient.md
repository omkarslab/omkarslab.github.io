---
id: 50
title: 'Microsoft&#8217;s World Wide Telescope gets a silverlight webclient!'
date: 2010-01-28T14:16:13+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=50
permalink: /2010/01/28/microsofts-world-wide-telescope-gets-a-silverlight-webclient/
sfw_comment_form_password:
  - QzbrQ5WxokAm
sfw_pwd:
  - aAG68KRYmxij
categories:
  - Uncategorized
tags:
  - Astronomy
  - Client
  - Hubble
  - Microsoft
  - Silverlight
  - Space
  - Web
  - World Wide Telescope
---
**<a href="http://research.microsoft.com/en-us/" target="_blank">Microsoft Research</a>** constantly works on new and innovative products. In Feb 2008 Microsoft released the World Wide Telescope as an initiative to create a virtual map of the universe, collaboratively using the imagery from ground and space telescopes. Initially WWT was available as a Windows Client.

<img src="http://lh4.ggpht.com/_Tf3uLIahhCQ/SrdamdbP1ZI/AAAAAAAAAQI/mQxZ7PeOGTw/s800/SGPhoto_2009_09_21%2013_50_38.jpg" border="0" />

Microsoft now also makes WWT available on a Web Client. To use WWT on your Silverlight supported browser. WWT provides images taken by numerous telescopes, including Hubble, Chandra and more&#8230;

<img src="http://lh5.ggpht.com/_Tf3uLIahhCQ/SrdanOZJJ6I/AAAAAAAAAQM/5k-xPjZFObc/s800/SGPhoto_2009_09_21%2014_14_09.jpg" border="0" />

WWT can be accessed at <a href="http://www.worldwidetelescope.org" target="_blank">www.worldwidetelescope.org</a>. Microsoft is trying to make most of its services Silverlight oriented in order increase the Internet popularity of the plugin.</p>