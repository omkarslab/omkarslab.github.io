---
id: 124
title: Stop updates from Google Buzz from appearing in the inbox
date: 2010-02-15T11:53:56+00:00
author: Omkar
layout: post
guid: http://omkarslab.co.cc/2010/02/15/stop-updates-from-google-buzz-from-appearing-in-the-inbox/
permalink: /2010/02/15/stop-updates-from-google-buzz-from-appearing-in-the-inbox/
sfw_comment_form_password:
  - 3ePTMXmc3g0n
sfw_pwd:
  - kCbSVLlC5CBP
categories:
  - Uncategorized
tags:
  - buzz
  - filter
  - gmail
  - Google
  - inbox
  - remove
  - stop
---
 <img alt="Google Buzz Logo" src="http://lh3.ggpht.com/_Tf3uLIahhCQ/S3kvILpdIoI/AAAAAAAAAlc/JnimTPpbq58/s800/SGPhoto_2010_02_15%2016_53_11.jpg" title="Google Buzz" class="alignleft" width="128" height="118" />The recent upgrade in Google&#8217;s web-based mail service, &#8220;Google Buzz&#8221; has created quite a buzz on the internet. Though the new service is being used widely since its launch, some users have less reasons to be happy due to constant appearances of Buzz updates in the inbox.

But most of us have missed the obvious solution to this issue. Filter BUZZ. For those who have still not figured out what I mean, use Gmail&#8217;s filter feature from settings, and filter all emails with &#8220;Has the words&#8221; Label:Buzz (use test search to be sure). Just ask them to &#8220;Skip the inbox&#8221; and you are done.

Once again, a few people just don&#8217;t want any socialising tool to interfere in their private time with Emails. Google has given a quick response for such users. You will soon find an option remove Buzz completely from your inbox.