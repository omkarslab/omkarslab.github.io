---
id: 38
title: Google UFO comes back!
date: 2010-01-28T14:11:21+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=38
permalink: /2010/01/28/google-ufo-comes-back/
sfw_comment_form_password:
  - kzQtd9bioUpy
sfw_pwd:
  - YI6gklbNjFAu
categories:
  - Uncategorized
tags:
  - Circles
  - Crop
  - Google
  - Horsell
  - UFO
  - UK
---
The Google UFO mystery continues as once again Google comes up with a UFO logo with a query &#8220;Crop Circles&#8221;. An assumed clue was tweeted by @Google. The clue is something like this &#8220;51.327629, -0.5616088&#8221;.

And here is the actual tweet by Google.

<table style="width: auto;" border="0">
  <tr>
    <td>
      <a href="http://picasaweb.google.com/lh/photo/r3pSMfj4-Y9oGsHHGBd3kA?authkey=Gv1sRgCLGxnIu8oozvMQ&feat=embedwebsite"><img src="http://lh5.ggpht.com/_Tf3uLIahhCQ/Sq9ACXE8Q1I/AAAAAAAAAMY/cGF74d2a_xA/s800/SGPhoto_2009_09_15%2011_12_11.jpg" border="0" /></a>
    </td>
  </tr>
  
  <tr>
    <td style="font-family:arial,sans-serif; font-size:11px; text-align:right">
      From <a href="http://picasaweb.google.com/omkark97/OmkarkhairCoCc?authkey=Gv1sRgCLGxnIu8oozvMQ&feat=embedwebsite">omkarkhair.co.cc</a>
    </td>
  </tr>
</table>

The url leads to the Google Logo snap on Google&#8217;s homepage

<p style="text-align: center;">
  <a href="http://twitpic.com/hsfgl" title="Share photos on twitter with Twitpic"><img src="http://twitpic.com/show/thumb/hsfgl.png" border="0" alt="Share photos on twitter with Twitpic" width="150" height="150" /></a>
</p>

The clue tweeted by Google seems to be a location. It is quite obvious that the figures seem very close to some kind Longitude and Latitude set. I tried the figures on Google Maps and it lead me to come place in UK called &#8220;Horsell&#8221;.

<p style="text-align: center;">
  <img src="http://lh3.ggpht.com/_Tf3uLIahhCQ/Sq9ZtEjvhmI/AAAAAAAAANk/IAutAbnLsPg/s800/SGPhoto_2009_09_15%2014_37_40.jpg" border="0" title="Google UFO gives a location to Horsell" width="511" height="400" />
</p>

On 5th Sept 2009 Google has tweeted a similar puzzle. There is no official report on the what Google is actually trying to convey. **<span style="color: #3366ff;">😐</span>**