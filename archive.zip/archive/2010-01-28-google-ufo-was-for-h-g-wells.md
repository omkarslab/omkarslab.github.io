---
id: 53
title: Google UFO was for H.G.Wells
date: 2010-01-28T14:17:20+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=53
permalink: /2010/01/28/google-ufo-was-for-h-g-wells/
sfw_comment_form_password:
  - zfPTPfJx6RG4
sfw_pwd:
  - 7cNWVamduH1f
categories:
  - Uncategorized
tags:
  - England
  - George
  - Google
  - H.G.Wells
  - Herbert
  - Horsell
  - Prank
  - Puzzle
  - UFO
  - War of the Worlds
---
I have covered two articles on mysterious logos on the Google homepage depicting UFOs and Crop Circles. Google had sent along clues for this mystery including a cryptic message and a numerical string. Today Google unveils the real mystery.

<p style="text-align: center;">
  <img src="http://2.bp.blogspot.com/_7ZYqYi4xigk/Srb8WgkT7dI/AAAAAAAAEkM/kwtx1NT4jzc/s400/hg_wells_birthday2009_part3_highres.jpg" border="0" title="Happy Birthday H.G.Wells" width="400" height="181" />
</p>

<p style="text-align: left;">
  Herbert George a British author of the book &#8220;The War of the Worlds (1898)&#8221; would have celebrated his 143th birthday today. Google depicted a series of events in the book including the 1st UFO landing and the clue which was a set of longitudes and latitudes. These sets were the location of Horsell in England, where the first UFO landing in the book took place. And guess what, my previous article had correctly mentioned Horsell as the hint of the logo.
</p>

<p style="text-align: left;">
  Google&#8217;s way of enjoying some special dates has always been unique. So was this one! <strong><span style="color: #3366ff;">😉</span></strong>
</p>