---
id: 30
title: Google gets Bigger!
date: 2010-01-28T14:08:00+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=30
permalink: /2010/01/28/google-gets-bigger/
sfw_comment_form_password:
  - gVFekyudM7Lw
sfw_pwd:
  - wICRd9c4y9PD
categories:
  - Uncategorized
tags:
  - Google
  - Marissa Mayer
  - Search
  - textbox
---
The Google blog stated yesterday that Google will be changing its homepage. No big changes, just some things could get bigger. &#8220;S-U-P-E-R sized&#8221; as they say.

These changes were noticed from today, as the Google textbox has increased its size significantly, and so did the font! But no change in the size of the Google logo. These changes are intended to improve visibility of the query given by the users and thus enhance the user interface.

<p style="text-align: center;">
  <a href="http://3.bp.blogspot.com/_7ZYqYi4xigk/SqgeZQO37fI/AAAAAAAAEg4/SzruS1piwMA/s1600-h/new-old-search-next.png" target="_blank"><img src="http://3.bp.blogspot.com/_7ZYqYi4xigk/SqgeZQO37fI/AAAAAAAAEg4/SzruS1piwMA/s400/new-old-search-next.png" border="0" title="Google gets Bigger!" width="400" height="147" /></a>
</p>

&#8220;Google has always been first and foremost about search, and we&#8217;re committed to building and powering the best search on the web — now available through a supersized search box.&#8221; quoted by Marissa Mayer, Google Vice President, Search Products & User Experience.</p>