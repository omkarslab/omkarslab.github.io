---
id: 99
title: 'Google Chrome: IE Extension'
date: 2010-01-28T14:48:21+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=99
permalink: /2010/01/28/google-chrome-ie-extension/
sfw_comment_form_password:
  - YVIqvC30HDtw
sfw_pwd:
  - VJbPbdp7bOeA
categories:
  - Uncategorized
tags:
  - Chrome
  - Explorer
  - Extension
  - Google
  - IE
  - Internet
  - Mircosoft
  - Tab
---
Google&#8217;s very own browser needs no introduction now. There are over a million addicts now who use it as a default browser. But then its annoying to switch back to IE when come specific websites you visit allow only IE users to crawl inside. Here is a tool that will reduce a step or two for you.

But first, all those of you who don&#8217;t know about the Google Chrome Developer version which has the extensions feature check this: <a href="http://dev.chromium.org/getting-involved/dev-channel" target="_blank">http://dev.chromium.org/getting-involved/dev-channel</a>

You can download the Google Chrome Developer version here: <a href="http://www.google.com/chrome/eula.html?extra=devchannel" target="_blank">http://www.google.com/chrome/eula.html?extra=devchannel</a>

Once you are done, you are all set to use the key feature &#8220;Extensions&#8221;. You can download the &#8216;IE tab&#8217; extension here: <a href="https://chrome.google.com/extensions/detail/hehijbfgiekmjfkfjpbkbammjbdenadd" target="_blank">https://chrome.google.com/extensions/detail/hehijbfgiekmjfkfjpbkbammjbdenadd</a>

Now that you are done, whenever your browser weeps about a website not letting it in just click on the &#8216;IE Tab&#8217; icon next to the address bar and you are in.</p> 

<p style="text-align: center;">
  <img src="http://lh5.ggpht.com/_Tf3uLIahhCQ/Sz9Hvf-wIWI/AAAAAAAAAiY/RPCyOzCo9_c/s800/SGPhoto_2010_01_02%2018_44_44.jpg" border="0" title="Google Chrome IE Tab" width="640" height="389" />
</p>

Well. Another advantage of using the IE tab is you can add the websites you frequently visit that need IE in the &#8216;IE Tab Auto URL&#8217; so the next time you visit the website from chrome, it will automatically open in the &#8216;IE Tab&#8217;.

<p style="text-align: center; ">
  <img src="http://lh6.ggpht.com/_Tf3uLIahhCQ/Sz9HyrtkeiI/AAAAAAAAAik/LpvTMfwy7hg/s800/SGPhoto_2010_01_02%2018_46_15.jpg" border="0" title="Google Chrome IE Tab" width="435" height="433" />
</p>

You can access the &#8216;IE Tab Auto URL&#8217; list by clicking on the funnel icon in the IE Tab.

I specifically use it for viewing my local files as nothing can compete the Explorer view to view files.</p> 

<p style="text-align: center;">
  <img src="http://lh4.ggpht.com/_Tf3uLIahhCQ/Sz9HxoIeCsI/AAAAAAAAAig/jlPvC3OPY6I/s800/SGPhoto_2010_01_02%2018_45_57.jpg" border="0" title="Google Chrome IE Tab" width="640" height="389" />
</p>

Have a look.</p> 

I will be listing in some great extensions for Google Chrome soon&#8230;