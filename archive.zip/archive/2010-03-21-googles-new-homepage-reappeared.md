---
id: 179
title: 'Google&#8217;s new homepage reappeared!'
date: 2010-03-21T11:08:59+00:00
author: Omkar
excerpt: Google seems to working actively on a new homepage. Few users across the globe have been noticing a preview for shot time. Read to view screenhots.
layout: post
guid: http://www.omkarslab.co.cc/?p=179
permalink: /2010/03/21/googles-new-homepage-reappeared/
sfw_comment_form_password:
  - XRy5t3mWsDAq
sfw_pwd:
  - 5ZQUktnPb67Q
categories:
  - Web Reviews
tags:
  - Google
  - homepage
  - new
  - preview
  - reappear
  - screenshot
  - update
---
There is news of Google working on a new homepage since last year. I came across a couple of articles that published the screenshots of the upcoming page which appeared for a short time to few users. Today we noticed it as well (sadly it din&#8217;t stay for long), but with a few differences from the screenshots published before.

**Check the older screenshots here :** [**http://www.theregister.co.uk/2009/11/26/google\_new\_look\_test\_november_09/**](http://www.theregister.co.uk/2009/11/26/google_new_look_test_november_09/)

<p style="text-align: center;">
  <a href="http://picasaweb.google.com/lh/photo/lUVCxH3pShdwbMtABrTOWA?authkey=Gv1sRgCLGxnIu8oozvMQ&feat=embedwebsite"><img src="http://lh6.ggpht.com/_Tf3uLIahhCQ/S6X1Lq-uQ0I/AAAAAAAAApQ/BBw4i338crY/s800/SGPhoto_2010_03_21%2012_44_02.jpg" alt="Click to enlarge" width="560" height="303" /></a>
</p>

The old new home page (funny) seems to have blue buttons while now Google seems to like the Gray ones more.  The surrounding text as well has been changed to a lighter shade, which eventually highlights the Google logo (which seems unchanged).

<p style="text-align: center;">
  <a href="http://picasaweb.google.com/lh/photo/0pnoS91EPB177ciZRBEIHw?authkey=Gv1sRgCLGxnIu8oozvMQ&feat=embedwebsite"><img src="http://lh5.ggpht.com/_Tf3uLIahhCQ/S6X1PSAy24I/AAAAAAAAApU/B02gzyf8VWo/s800/SGPhoto_2010_03_21%2012_45_25.jpg" alt="Click to Enlarge" width="560" height="307" /></a>
</p>

Here is the Google search page. Again, here the blue highlights have been removed as compared to the older screenshots. But honestly I&#8217;ll be waiting for this new look to become permanent. The Google homepage has always been a clean view, but this change makes it look exceptionally futuristic and cleaner.

Most user would wonder why is Google giving a peek of these pages to few users? Was it a mistake? Did a Googler working on the new page accidently push the &#8220;UPDATE&#8221; button? Well, I would say no. This is a great way to get a feedback on the new page from a small audience before publishing. Who knows, right now some programmed Google-Spider must be crawling pages to get reviews on the glimpse of  New Google homepage. Reading this page will obviously make it happy 😉

If you have seen the new webpage or got a screenshot of it, post a feedback comment or contact me **<a href="http://www.omkarslab.co.cc/contact/" target="_blank">HERE</a>**