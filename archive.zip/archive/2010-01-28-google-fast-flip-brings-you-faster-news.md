---
id: 44
title: Google Fast Flip brings you faster news
date: 2010-01-28T14:13:54+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=44
permalink: /2010/01/28/google-fast-flip-brings-you-faster-news/
sfw_comment_form_password:
  - VIVgx5Oyxekd
sfw_pwd:
  - doOvTR87IWaK
categories:
  - Uncategorized
tags:
  - Fast
  - Fast Flip
  - Flip
  - Google
  - Krishna Bharat
  - Lab
---
<p style="text-align: justify;">
  Now this does not mean Google is bringing the news before hand. It just means that now you can browse the news faster that before. This Lab edition service will provide pages from multiple news websites on one single screen in an image format.
</p>

<p style="text-align: justify;">
  Google says, that mostly it takes 10secs for a news website page to load on a broadband connection due to heavy scripts and CSS styles. Instead if these pages load directly the way we print a page, users could browse through news faster than ever. This is the concept of Google Fast Flip.
</p>

<p style="text-align: center;">
  <a href="http://2.bp.blogspot.com/_7ZYqYi4xigk/Sq7KPzR-MkI/AAAAAAAAEhs/1YoEqpvxpJQ/s1600-h/Fast+Flip+scsh+for+blog+post.png" target="_blank"><img src="http://2.bp.blogspot.com/_7ZYqYi4xigk/Sq7KPzR-MkI/AAAAAAAAEhs/1YoEqpvxpJQ/s400/Fast+Flip+scsh+for+blog+post.png" border="0" title="Google Fast Flip brings you faster news" width="400" height="234" /></a>
</p>

<p style="text-align: justify;">
  Fast Flip as the name says, enables you to flip through sequential pages of news content faster. Google has partnered with &#8220;dozens of top publishers including <span style="font-style: italic;">New York Times</span>, the<span style="font-style: italic;">Atlantic</span>, the <span style="font-style: italic;">Washington Post</span>, <span style="font-style: italic;">Salon</span>, <span style="font-style: italic;">Fast Company</span>, <span style="font-style: italic;">ProPublica</span> and <span style="font-style: italic;">Newsweek</span>&#8221; as the Google blog suggests. These publishers share the revenew.
</p>

<p style="text-align: justify;">
  The Website&#8217;s mobile version is compatible on Android and i-Phones as well, which is accessible on the same address. The brain behind Google Fast Flip is an Indian named Krishna Bharat a Distinguished Researcher, Google News.
</p>

<p style="text-align: justify;">
  <a href="http://googleblog.blogspot.com/2009/09/read-news-fast-with-google-fast-flip.html" target="_blank"><strong>Source: Google Blog</strong></a>
</p>