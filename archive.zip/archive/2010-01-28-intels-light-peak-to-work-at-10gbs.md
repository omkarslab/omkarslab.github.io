---
id: 56
title: 'Intel&#8217;s Light Peak to work at 10GB/s'
date: 2010-01-28T14:18:24+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=56
permalink: /2010/01/28/intels-light-peak-to-work-at-10gbs/
sfw_comment_form_password:
  - 7xgXIb4eyFZx
sfw_pwd:
  - SzlEZhi73XBU
categories:
  - Uncategorized
tags:
  - Apple
  - Data Transfer
  - High Speed
  - Intel
  - Light Peak
  - Optical Computing
  - Optical Fiber
---
The Computer Industry is thriving hard to satisfy the ever growing need of data storage all over the globe. But when you store a Tera byte of data on your computer, you need faster means of data transfer too.This growth in data storage needs has thus given rise to a demand for a new high speed data transfer technology.

Intel&#8217;s Light Peak is an Optical Module capable to transfer data at the speed of 10GB/s. The Module consists of miniaturized laser and photo-sensors which work on the optical signals. There multiple advantages of this technology.</p> 

1) The size is reduced exponentially, as the there is no EMI however close the circuit gets.

2) The optical cables that power this module are extremely thin.

3) No doubt the Optical Circuit is way more faster than our conventional Copper circuits.

4) Can handle multiple I/O protocols on a single cable.

5) Very high bandwidth.

Light Peak is expected to work at a speed of upto 100GB/s over the next decade. Intel aims to even bring this technology into the main stream of computers where our Computer peripherals would operate on this module. If light peak comes into main stream computing, then the processing capability of our PCs will increase beyond imagination. Apple is suspected to have a major contribution in the initiative of this product from Intel. We might even expect Apple machines to be shipped with Light Peak soon. Intel aims to ship the first batch of the Light Peak connector in 2010.