---
id: 234
title: 'Picasa &#8211; People Identification'
date: 2010-04-06T13:58:48+00:00
author: Omkar
excerpt: Digital albums have successfully crawled their way into the lives of computer users. The traditional methods of storing photos from trips and image collections are being dominated by photo managers. One the latest additions to the features in these digital album managers is the "Face Tag". But not many are happy with just that feature. For most, its tiring to tag each and every face from a photo. If you are one of these, this might interest you!
layout: post
guid: http://www.omkarslab.co.cc/?p=234
permalink: /2010/04/06/picasa-people-identification/
sfw_comment_form_password:
  - w9O8Pnsf3Ttm
sfw_pwd:
  - NpnfMsjT2mD5
categories:
  - Software
tags:
  - album
  - detection
  - face
  - Google
  - image
  - manager
  - photo
  - picasa
  - tag
---
<p style="text-align: justify;">
  Digital albums have successfully crawled their way into the lives of computer users. The traditional methods of storing photos from trips and image collections are being dominated by photo managers. One the latest additions to the features in these digital album is the &#8220;Face Tag&#8221;. But not many are happy with just that feature. For most, its tiring to tag each and every face from a photo. If you are one of these, this might interest you!
</p>

<p style="text-align: justify;">
  Picasa 3.6 brings in a new feature that detects all the faces in an album and groups similar faces together. So now, you will have to name a face lesser times than before. Picasa tries to identify that face in other photos and tags them. Incase its not sure, it will give you a prompt.
</p>

<p style="text-align: justify;">
  [http://www.youtube.com/watch?v=fJ7IhTviBf4]
</p>

<p style="text-align: justify;">
  The identification is not that efficient, but still saves you a few clicks. I guess that will do for now, hope for more in the future. 😉
</p>