---
id: 8
title: Google Code Jam Begins!
date: 2010-01-28T13:47:53+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=8
permalink: /2010/01/28/google-code-jam-begins/
sfw_comment_form_password:
  - LhRhPHzeGNBV
sfw_pwd:
  - 9LNczMtK2KOx
categories:
  - Uncategorized
tags:
  - "2009"
  - Code Jam
  - Google
  - Internet
---
Google Code Jam is a coding competition in which professional and student programmers are asked to solve complex algorithmic challenges in a limited amount of time. The contest is all-inclusive: Google Code Jam lets you program in the coding language and development environment of your choice.

<p style="text-align: center;">
  <img src="http://code.google.com/codejam/images/logo/logo_image4.gif" border="0" />
</p>

The Qualification round of Google Code Jam began today on September 2nd 23:00 UTC Google hosts this contest for programmers around the globe to advertise their creativity in coding. Google has also announced a Grand prize of $5000 this year.