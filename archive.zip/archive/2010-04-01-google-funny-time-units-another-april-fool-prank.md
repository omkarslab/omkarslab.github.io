---
id: 226
title: 'There is more than Topeka to Google&#8217;s April fools prank &#8211; Funny time units'
date: 2010-04-01T08:54:25+00:00
author: Omkar
excerpt: Google displays on funny time units on search results page. Another April Fools prank.
layout: post
guid: http://www.omkarslab.co.cc/?p=226
permalink: /2010/04/01/google-funny-time-units-another-april-fool-prank/
sfw_comment_form_password:
  - 6xDhMOccb66O
sfw_pwd:
  - SBnICGJ0ctJ2
categories:
  - Internet
tags:
  - april
  - duration
  - fool
  - funny
  - Google
  - load
  - page
  - Time
---
About an hour ago I posted a topic on Google&#8217;s April Fools prank by changing its name to Topeka &#8211; <a href="http://www.omkarslab.co.cc/2010/04/01/april-fools-news-google-now-topeka/" target="_blank">Google now Topeka</a> &#8211; <a href="http://www.omkarslab.co.cc/2010/04/01/april-fools-news-google-now-topeka/" target="_blank">http://www.omkarslab.co.cc/2010/04/01/april-fools-news-google-now-topeka/</a>.

But there seems more to it. Googling around, I noticed a tiny change in Google search results. Now your search page loads in Hertz, Jiffies or maybe Centibeats.

<p style="text-align: center;">
  <a href="http://picasaweb.google.com/lh/photo/eRHnCuwkSRhssCNc3ics-w?authkey=Gv1sRgCLGxnIu8oozvMQ&feat=embedwebsite" target="_blank"><img src="http://lh4.ggpht.com/_Tf3uLIahhCQ/S7RbJkapp-I/AAAAAAAAAp0/d--MeAQl4Jc/s400/SGPhoto_2010_04_01%2013_53_20.jpg" alt="" width="400" height="297" /></a>
</p>

Google search results page shows the time taken for page load/provide search results to the upper right corner as seen in the screenshot. Today the unit of time seems to have slipped through the minds of Google (usually seconds). The page displays the time duration in a different format. Here are a few of them.

<p style="text-align: center;">
  <img class="aligncenter" title="Google crazy times" src="http://lh5.ggpht.com/_Tf3uLIahhCQ/S7RdG4IR2AI/AAAAAAAAAqU/Q5vB6m5QCkE/s800/SGPhoto_2010_04_01%2013_53_49.jpg" alt="" width="347" height="76" /><img class="aligncenter" title="Google crazy times" src="http://lh4.ggpht.com/_Tf3uLIahhCQ/S7RdG9acG8I/AAAAAAAAAqY/pw_aVG-qAX4/s800/SGPhoto_2010_04_01%2013_54_00.jpg" alt="" width="400" height="73" /><img class="aligncenter" title="Google crazy times" src="http://lh4.ggpht.com/_Tf3uLIahhCQ/S7RdHGQvjGI/AAAAAAAAAqc/LLeUkb6696E/s800/SGPhoto_2010_04_01%2013_58_44.jpg" alt="" width="456" height="72" />
</p>

Some more of the terms include&#8230; warp 9.09, 0.19 centons, 1.21 gigawatts, at 4.17 hertz. No no. Thats not all of them&#8230; go Google around and you&#8217;ll see more. Google has great plans to make April Fools fun (atleast on the Internet).

Cheers! 😛