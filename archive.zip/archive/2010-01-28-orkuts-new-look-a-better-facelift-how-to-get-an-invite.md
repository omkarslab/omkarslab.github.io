---
id: 82
title: 'Orkut&#8217;s New Look: A better Facelift, How to get an invite?'
date: 2010-01-28T14:28:42+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=82
permalink: /2010/01/28/orkuts-new-look-a-better-facelift-how-to-get-an-invite/
sfw_comment_form_password:
  - FlcYTieIt8pa
sfw_pwd:
  - tad1hNy49B9z
categories:
  - Uncategorized
tags:
  - Easy Scrap
  - Google
  - How to get New Orkut Invite
  - Invitation
  - New Look
  - Orkut
---
Orkut has recently received a facelift, which is being activated for users by invitation. We got ours! And we will take you to the tour of this new look Orkut has bought itself&#8230;

The whole new look may seem similar to facebook, but it has its own changes too. The first change i noticed is the whole new placement of information. On the top most position of the page, the Google service bar is present, which will make direct access to your Gmail, Calendar and other Google services more easy.

<p style="text-align: center;">
  <img src="http://lh6.ggpht.com/_Tf3uLIahhCQ/Su8VpxaLr0I/AAAAAAAAAak/fSt4NVh1IjU/s800/SGPhoto_2009_11_02%2022_51_36.jpg" border="0" title="New Orkut" width="600" height="380" />
</p>

Next we see, the recent visitors page has a new method of display, and it just gets better! The recent visitors will now be shown with Display pics instead of names. You may also notice the scroll bar in the &#8220;My Friends&#8221; module, which indicates that now all friends will be handy on the homepage itself.

<p style="text-align: center;">
  <img src="http://lh4.ggpht.com/_Tf3uLIahhCQ/Su8VmOnUl7I/AAAAAAAAAZ0/H07Bg_P1nGM/s800/SGPhoto_2009_11_02%2022_44_02.jpg" border="0" title="New Orkut" width="600" height="283" />
</p>

The Orkut search now contains two options. Search in Orkut and the Web. While the Friends module has the friends search.

<p style="text-align: center;">
  <img src="http://lh5.ggpht.com/_Tf3uLIahhCQ/Su8Vmlu36iI/AAAAAAAAAZ4/k-A589co7X0/s800/SGPhoto_2009_11_02%2022_44_46.jpg" border="0" title="New Orkut" width="313" height="170" />
</p>

Here you see I searched for &#8220;An&#8221; and the list got refined according my query.</p> 

<p style="text-align: center;">
  <img src="http://lh3.ggpht.com/_Tf3uLIahhCQ/Su8Vn3N420I/AAAAAAAAAZ8/Pa5rPSyMpzA/s800/SGPhoto_2009_11_02%2022_45_11.jpg" border="0" title="New Orkut" width="600" height="263" />
</p>

Another good news is, Orkut Feed reader/Google Feed reader combo gets integrated to Orkut. All other applications are listed in the &#8220;More&#8221; Tab. The access to various features of Orkut has become significantly easier with this.</p> 

<p style="text-align: center;">
  <img src="http://lh3.ggpht.com/_Tf3uLIahhCQ/Su8VoGXrW-I/AAAAAAAAAaA/pwYE4tmoNhY/s800/SGPhoto_2009_11_02%2022_46_04.jpg" border="0" title="New Orkut" width="574" height="128" />
</p>

Scrapping will be more fun as handy tools are now available to decorate your scraps. Also a tool to add videos.

The look might feel a bit confusing at first glimpse, but then it gets better as you understand the flow of the links. Google&#8217;s upcoming service &#8220;Google Wave&#8221; is expected to be integrated in Orkut with help of Apps after its public launch. The new look satisfactorily compliments Wave.

Here is a Tip to get your Invite the fastest. remeber.. second hand invites can&#8217;t invite others, so only you receive an invite from Orkut, you will be able to invite others. Here&#8217;s what you got to do. <a href="https://spreadsheets.google.com/viewform?formkey=dEd3Zk03bGMzbFFFTXJSQmtMeUN6V3c6MQ" target="_blank">https://spreadsheets.google.com/viewform?formkey=dEd3Zk03bGMzbFFFTXJSQmtMeUN6V3c6MQ</a>

Click on the link above, and fill it up. This will enroll you for the invite list. I got mine in 2 days. You can also visit, <a href="http://www.orkut.com/neworkut" target="_blank">http://www.orkut.com/neworkut</a> for more details.

While users who wish to stick back to the older view are always welcomed with a link to revert back. Happy Orkutting! **<span style="color: #3366ff;">🙂</span>**