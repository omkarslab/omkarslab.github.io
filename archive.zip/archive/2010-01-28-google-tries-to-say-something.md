---
id: 15
title: Google tries to say something!
date: 2010-01-28T13:52:24+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=15
permalink: /2010/01/28/google-tries-to-say-something/
sfw_comment_form_password:
  - 3GqSOuovoP7Y
sfw_pwd:
  - wNNT20ZAdP4B
categories:
  - Uncategorized
tags:
  - Aliens
  - April Fool
  - Code
  - Google
  - Japanese game
  - Joke
  - twitter
  - UFO
---
Google tried to say something mysterious on its homepage. Google&#8217;s twitter account also tried to say something similar.

Here&#8217;s a screenshot

<p style="text-align: center;">
  <img class="caption" src="http://omkarslab.co.cc/images/stories/sgphoto_2009_09_05 16_50_03.png" border="0" title="Google Tweets" />
</p>

While the Google logo portrayed an UFO carrying away the &#8220;O&#8221; from Google.

[<img src="http://twitpic.com/show/thumb/giyxf.png" border="0" alt="Share photos on twitter with Twitpic" width="150" height="150" />](http://twitpic.com/giyxf "Share photos on twitter with Twitpic")

The text stated by Google along with the logo

**1.12.12 25.15.21.18 15 1.18.5 2.5.12.15.14.7 20.15 21.19**

is supposed to be a coded message. All the numbers in the message are supposed to be alphabets according to their alphabetical sequence. Like 1=A, 2=B bla bla bla&#8230;

So when you follow the rules you get this string: &#8220;**All your base are belong to us**&#8220;.  
Reportedly, this phrase is taken from an old Japanese video game that was translated poorly. Google is popular for its distinguished ways of making their services fun to use. Like the most popular April Fool jokes from Google. For all those Internet addicts, such a thing surely made their day.<span style="color: #005fff;"><strong> 😛</strong></span></p>