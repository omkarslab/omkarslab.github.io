---
id: 176
title: Technorati verification
date: 2010-03-21T07:07:44+00:00
author: Omkar
layout: post
guid: http://www.omkarslab.co.cc/?p=176
permalink: /2010/03/21/technorati-verification/
sfw_comment_form_password:
  - lnnRM1QWzaX8
sfw_pwd:
  - vgrYh4wj33ff
categories:
  - Uncategorized
---
BCM56YDC2B6B