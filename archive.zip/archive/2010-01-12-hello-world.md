---
id: 1
title: Hello world!
date: 2010-01-12T04:56:02+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=1
permalink: /2010/01/12/hello-world/
sfw_comment_form_password:
  - f5Yie2K2zKhO
sfw_pwd:
  - Zfloi95jxvvg
categories:
  - Uncategorized
---
Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!