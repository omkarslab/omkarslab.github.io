---
id: 96
title: Joomla Ravenswood a Great tool for PHP and Joomla fans
date: 2010-01-28T14:47:19+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=96
permalink: /2010/01/28/joomla-ravenswood-a-great-tool-for-php-and-joomla-fans/
sfw_comment_form_password:
  - uB5JJ8zFIFqy
sfw_pwd:
  - cETPqDhuGCq5
categories:
  - Uncategorized
tags:
  - joomla
  - mysql
  - php
  - phpmyadmin
  - ravenswood
  - server
  - virtual
---
Well, I have not blogged for over a month now due to hectic schedules and plan to get back on track now as we enter the New year. So Happy New year to all.

Getting back to the topic I plan to discuss today. I have been using this Ravenswood Joomla Server for about an year now and I found it unfair not to talk about it, as its really helpful. Basically this tool is made for people to test their Joomla websites on a &#8216;localhost&#8217;.

Okay, so what is Joomla Ravenswood? Joomla is an Open Source PHP based CMS and Joomla users are not always techies with too much knowledge about servers. Ravenswood provides a solution for such people and even techies who are on the move with an executable server package which uses the Uniform Server with Joomla pre-installed. All you have to do is, run the &#8216;Joomla.exe&#8217; in the package and your server with a virtual drive is ready on your desktop. Later you can customise Joomla as per your taste and necessity.

So how will Ravenswood provide any support for PHP fans? Well. Joomla is a PHP based CMS so the virtual server comes pre-installed with PHP and MySQL. Now all you have to do is create a new directory for your PHP based project in the Server root and add databases from PHP myAdmin which is also pre-installed, and you are set!

Here is the link to download Joomla Raveswood from the Joomla Code website: <http://joomlacode.org/gf/project/joomlalite/frs/>

You can get the Details of the tools at its official website: [http://www.ravenswoodit.co.uk/index.php?option=com\_docman&task=cat\_view&gid=81&Itemid=13](http://www.ravenswoodit.co.uk/index.php?option=com_docman&task=cat_view&gid=81&Itemid=13)

I have slated down the includes of the server here:

1) Joomla Uniform Server 1.0 beta

2) PHP 4.3.11

3) phpMyAdmin 2.6.4

4) MySQL 4.0.20

5) Joomla < 1.5 (Directory: /Joomla) You can replace the contents of this folder with a newer version of Joomla

I am trying to figure out a way to upgrade the PHP version here, but failed. Incase anyone figures out the way to do so do comment or use the contact form on this website.