---
id: 239
title: 'Creating 3D Panorama&#8217;s with Microsoft&#8217;s Photosynth'
date: 2010-05-05T13:48:52+00:00
author: Omkar
layout: post
guid: http://www.omkarslab.co.cc/?p=239
permalink: /2010/05/05/creating-3d-panoramas-with-microsofts-photosynth/
sfw_comment_form_password:
  - kEDf2sA1aMtG
sfw_pwd:
  - q003KATcWz50
categories:
  - Uncategorized
---
<p style="text-align: justify;">
  It&#8217;s been over a couple of months since Microsoft has released this really awesome tool to easily create three dimensional panorama&#8217;s within a few clicks. This Silverlight powered tool saves you the trouble of sitting and stitching images together to recreate the scene you captured from your weekend trip in multiple frames.
</p>

<p style="text-align: center;">
  <img class="alignnone" title="Microsoft's Photosynth" src="http://lh6.ggpht.com/_Tf3uLIahhCQ/S-F1DL0AylI/AAAAAAAAArY/fEKpG41QZ6A/s800/microsoft-photosynth-logo.jpg" alt="" width="280" height="107" />
</p>

<p style="text-align: justify;">
  Microsoft&#8217;s Photosynth, accessible at <a href="http://www.photosynth.net" target="_blank">www.photosynth.net</a> is basically a web-based tool. You can upload the images you intend to stitch, and you are done! Photosynth automatically mashes these images to create a 3D scene that can be viewed by anyone.
</p>

<p style="text-align: justify;">
  Have a look at a Photosynth I made:
</p>

<p style="text-align: justify;">
  <a href="http://photosynth.net/view.aspx?cid=cf9f6b8a-821b-4f6c-8850-2d4d27f8dc23&" target="_blank">http://photosynth.net/view.aspx?cid=cf9f6b8a-821b-4f6c-8850-2d4d27f8dc23&</a>
</p>

<p style="text-align: justify;">
  This new technology will really help travels share their experiences in really good detail. The traditional methods of sharing images in albums hakes it difficult to recreate the exact locations of each picture, and their relations to each other in terms of angle, distance and direction. You can upload images you intend to stitch together (should have some common areas for the tool to detect a synth), from a client application which can be download from here.
</p>

<p style="text-align: justify;">
  IE users : <a href="http://photosynth.net/create.aspx" target="_blank">http://photosynth.net/create.aspx</a>
</p>

<p style="text-align: justify;">
  Other browsers : <a href="http://photosynth.en.softonic.com/download" target="_blank">photosynth.en.softonic.com/download</a>
</p>

<p style="text-align: justify;">
  Once you install this application, create an account on Photosynth.net and Sign-in to the application with your associated Live-id. You can now drag drop or add the images you want to stitch, and upload. And thats it! You are Done!
</p>

<p style="text-align: justify;">
  Microsoft has hinted an offline release of Photosynth (on the Photosynth forum), which would be a paid-to-use version.
</p>