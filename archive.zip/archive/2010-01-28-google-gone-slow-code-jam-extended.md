---
id: 11
title: 'Google Gone slow &#8211; Code Jam Extended'
date: 2010-01-28T13:50:19+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=11
permalink: /2010/01/28/google-gone-slow-code-jam-extended/
sfw_comment_form_password:
  - 4NzKXcIuckAn
sfw_pwd:
  - wjcVY4Ggs2gB
categories:
  - Uncategorized
tags:
  - Google
  - Google Code Jam 2009
  - Internet
  - Reader
  - Server Down
  - Slow
---
Today google promotes Google Reader on its home page and there are reports from around the globe about Google services being slow. Especially Google reader itself is providing really slow services. There are complaints from many user regarding errors while operating Gmail, while I am personally experincing errors accessing Orkut. Its is suspected that large number of hits on the Google reader service might me taking too much of the Google bandwidth.</p> 

<p style="text-align: center;">
  <img class="caption" src="http://omkarslab.co.cc/images/stories/google_slow_tweeter.png" border="0" alt="Tweets from around the Glode about Google's services" title="Tweets from around the Glode about Google's services" />
</p>

Tweets are poping in continuously on twitter describing user experinces about Google. Ironically Google Code Jam 2009 is running right now, which will end on 3rd September 23.00 UTC. Google has been experincing similar problems multiple times since last year. Google is known for it efficient service in the Internet industry, and hopefully it will figure out a solution to this problem.

_Modification (3rd Sept 2009 15:07 IST)_

The problem seems to have got some attention lately. All the Google Code Jam participants were informed via Email by Google that Google Code Jam will be extended to 1:00 UTC 4th Sept 2009 officially.

I have attached the Email sent by Google in this artcle below.

<table class="cf gJ" style="border-collapse: collapse; margin-top: 0px; width: auto;" border="0" cellpadding="0">
  <tr>
    <td class="gF gK" style="margin: 0px; font-family: arial,sans-serif; text-align: left; white-space: nowrap; padding-right: 0px; vertical-align: top; width: 305px; padding-top: 0px;">
      <table class="cf gJ" style="border-collapse: collapse; margin-top: 0px; width: auto;" border="0" cellpadding="0">
        <tr>
          <td class="gG" style="margin: 0px; font-family: arial,sans-serif; text-align: right; color: #777777; white-space: nowrap; vertical-align: top; width: 0px;" colspan="2">
            <span class="gI" style="cursor: auto; white-space: nowrap;"><em>sender time</em></span>
          </td>
          
          <td class="gL" style="margin: 0px; font-family: arial,sans-serif; white-space: normal; vertical-align: top; width: 237px;" colspan="2">
            <span class="gI" style="cursor: auto;"><span class="ik" style="vertical-align: top; position: relative; top: -1px;"><em><img src="http://mail.google.com/mail/images/cleardot.gif" border="0" width="16" height="16" /></em></span><em>Sent at 11:13 (UTC).</em></span>
          </td>
        </tr>
        
        <tr>
          <td class="gG" style="margin: 0px; font-family: arial,sans-serif; text-align: right; color: #777777; white-space: nowrap; vertical-align: top; width: 0px;" colspan="2">
            <span class="gI" style="cursor: auto; white-space: nowrap;"><em>reply-to</em></span>
          </td>
          
          <td class="gL" style="margin: 0px; font-family: arial,sans-serif; white-space: normal; vertical-align: top; width: 237px;" colspan="2">
            <span class="gI" style="cursor: auto;"><span class="ik" style="vertical-align: top; position: relative; top: -1px;"><em><img class="QrVm3d" src="http://mail.google.com/mail/images/cleardot.gif" border="0" width="16" height="16" name="upi" /></em></span><em>nobody@google.com<br /></em></span>
          </td>
        </tr>
        
        <tr>
          <td class="gG" style="margin: 0px; font-family: arial,sans-serif; text-align: right; color: #777777; white-space: nowrap; vertical-align: top; width: 0px;" colspan="2">
            <span class="gI" style="cursor: auto; white-space: nowrap;"><em>to</em></span>
          </td>
          
          <td class="gL" style="margin: 0px; font-family: arial,sans-serif; white-space: normal; vertical-align: top; width: 237px;" colspan="2">
            <span class="gI" style="cursor: auto;"><span class="ik" style="vertical-align: top; position: relative; top: -1px;"><em><img class="df QrVm3d" src="http://mail.google.com/mail/images/cleardot.gif" border="0" width="16" height="16" name="upi" /></em></span><em>************@gmail.com<br /></em></span>
          </td>
        </tr>
        
        <tr>
          <td class="gG" style="margin: 0px; font-family: arial,sans-serif; text-align: right; color: #777777; white-space: nowrap; vertical-align: top; width: 0px;" colspan="2">
            <span class="gI" style="cursor: auto; white-space: nowrap;"><em>date</em></span>
          </td>
          
          <td class="gL" style="margin: 0px; font-family: arial,sans-serif; white-space: normal; vertical-align: top; width: 237px;" colspan="2">
            <span class="gI" style="cursor: auto;"><span class="ik" style="vertical-align: top; position: relative; top: -1px;"><em><img src="http://mail.google.com/mail/images/cleardot.gif" border="0" width="16" height="16" /></em></span><em>3 September 2009 11:13</em></span>
          </td>
        </tr>
        
        <tr>
          <td class="gG" style="margin: 0px; font-family: arial,sans-serif; text-align: right; color: #777777; white-space: nowrap; vertical-align: top; width: 0px;" colspan="2">
            <span class="gI" style="cursor: auto; white-space: nowrap;"><em>subject</em></span>
          </td>
          
          <td class="gL" style="margin: 0px; font-family: arial,sans-serif; white-space: normal; vertical-align: top; width: 237px;" colspan="2">
            <span class="gI" style="cursor: auto;"><span class="ik" style="vertical-align: top; position: relative; top: -1px;"><em><img src="http://mail.google.com/mail/images/cleardot.gif" border="0" width="16" height="16" /></em></span><em>Qualification Round extended</em></span>
          </td>
        </tr>
        
        <tr>
          <td class="gG" style="margin: 0px; font-family: arial,sans-serif; text-align: right; color: #777777; white-space: nowrap; vertical-align: top; width: 0px;" colspan="2">
            <span class="gI" style="cursor: auto; white-space: nowrap;"><em>mailed-by</em></span>
          </td>
          
          <td class="gL" style="margin: 0px; font-family: arial,sans-serif; white-space: normal; vertical-align: top; width: 237px;" colspan="2">
            <span class="gI" style="cursor: auto;"><span class="ik" style="vertical-align: top; position: relative; top: -1px;"><em><img src="http://mail.google.com/mail/images/cleardot.gif" border="0" width="16" height="16" /></em></span><em>apphosting.bounces.google.com</em></span>
          </td>
        </tr>
        
        <tr>
          <td style="font-family: arial, sans-serif; margin: 0px;" colspan="4">
          </td>
        </tr>
      </table>
    </td>
    
    <td class="gH" style="font-family: arial, sans-serif; text-align: right; white-space: nowrap; vertical-align: top; margin: 0px;">
      <em><br /></em>
    </td>
    
    <td class="gH cY8xve" style="font-family: arial, sans-serif; text-align: right; white-space: nowrap; vertical-align: top; margin: 0px;">
      <em><br /></em>
    </td>
  </tr>
</table>

 <span style="color: #000000; font-family: arial; font-size: 16px; line-height: normal; border-collapse: collapse;"></span>

<div class="gE ib gt" style="font-size: 13px; padding-left: 4px; padding-bottom: 3px; padding-right: 0px; cursor: auto;">
  <em><br /></em>
</div>

<div id=":1q" class="ii gt" style="font-size: 13px; margin-top: 5px; margin-right: 15px; margin-bottom: 5px; margin-left: 15px; padding-bottom: 20px;">
  <em>Due to a system error early in the qualification round, we are extending this round for another two hours to give those people who were affected another chance to participate. This issue has been resolved, allowing participants to download inputs without receiving an error message.</p> 
  
  <p>
    Both the qualification round and registration have been officially extended to 1:00 UTC, September 4th.
  </p>
  
  <p>
    If you have any questions, please email programmingcontest-feedback@</em><em>google.com.</p> 
    
    <p>
      The Google Code Jam Team</em></div>
    </p>