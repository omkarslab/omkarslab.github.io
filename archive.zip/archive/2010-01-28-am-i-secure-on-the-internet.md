---
id: 18
title: Am I Secure on the Internet?
date: 2010-01-28T13:59:17+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=18
permalink: /2010/01/28/am-i-secure-on-the-internet/
sfw_comment_form_password:
  - PDL7oIhjaxCD
sfw_pwd:
  - EyVIdJoTehMU
categories:
  - Uncategorized
tags:
  - Email
  - Internet
  - MD5
  - Password
  - Security
---
Recently a local news paper covered a news story about how some ethical hackers, hacked into a very popular website working on Government and Election issues and extracted a database weighing 0.6 million users. This database consisted of the Email address, Name, Username and the Password. Now, this hack is in no way related to the way the users of this website handled the website, but it is related to their personal security.

Most users, while signing up for a website provide a Password to the website that is usually same as the one used for signing up for the Email address. So when a website where the user has an account gets hacked, he indirectly risks his Email account to get hacked!</p> 

Now this is not as simple as it may sound. But yes it is possible. Usually websites save the password in the database after encryption. The most commonly used encryption technique is MD5 (Message Digest 5). After encrypting the password with MD5 a 32 character key is obtained which cannot be decoded back to obtain the password. This means that even if you can see the database, you cannot find the password. Brute force though is an alternative to find the password matching this key.

So why take chances? Below are some easy steps to follow while signing up on a Web Service.

1) If the web service does not relate to you in offline life (means a website that need not have your personal details), you can use a fake alias for the internet and use the fake name and address.

2) If you can create a proxy Email account which wont be used by you for Banking and Financial issues, using this Email address on such web services will prove highly beneficial.

3) Do not use the same password on the web service as the one used for the Email address you provide.</p> 

This will be enough to keep you safe from a security threat, even if your web service is breached into. But for all those users who find remembering two passwords difficult, here&#8217;s a trick. Keep a standard password and append it with the name of the web service.

Like suppose my Password is &#8220;**starrynight**&#8221; and my web service is &#8220;**yahoo**&#8220;, I&#8217;ll simply use the password &#8220;**starrynightyahoo**&#8220;.

Now you can make it more complicated to ensure total security but placing the web service&#8217;s name in the middle of your password. Like say my lucky no: is 5 so i&#8217;ll place the Web service after the 5th character, so now I have &#8220;**starryahooynight**&#8220;.

Come on now this is enough of a trick, create your own template of placing the Password and the Web service and enjoy maximum security 😉