---
id: 21
title: 'Yahoo!&#8217;s own Twitter is called MEME'
date: 2010-01-28T14:01:47+00:00
author: Omkar
layout: post
guid: http://feeds.omkarkhair.co.cc/?p=21
permalink: /2010/01/28/yahoos-own-twitter-is-called-meme/
sfw_comment_form_password:
  - EulhYitS0fQe
sfw_pwd:
  - 7vymrSmBNRPA
categories:
  - Uncategorized
tags:
  - API
  - Evan Williams
  - Jerry Yang
  - MEME
  - micro-blogging
  - twitter
  - Yahoo
---
<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">With all those celebrities running around Twitter, the popular micro-blogging service, Yahoo! has decided launch its own micro-blogging service called “MEME”.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">Yahoo! has facing a lot of property shutdowns lately, still it has decided to come up with a new service to lure users to their domain. Yahoo!.Inc had launched its Email service some 12 years back. It still has a considerable amount of users depending on its Email service, but some other services launched by Yahoo! were not lucky enough. Yahoo! launched MEME in August 2009 in Spanish and has made the service available in English this week.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">Most netizens believe that Yahoo! MEME will not be able to give a fair competition to Twitter as the every growing popularity of Twitter in very field from Media to MNCs is unbeatable. Majority of users are reluctant to use Yahoo! MEME as they already have Twitter and don’t really find a reason to switch to another service leaving their 10,000’s of tweets useless. There are considerable changes in MEME, such as attaching pictures to the message directly instead of pasting a link, same is with a Video. This could lure a few to the service, but such type of sharing is not the real reason why Twitter is popular.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">Twitter has a wide range of multi-purpose applications on the Internet which indirectly advertise Twitter but also generates its huge lot of users addicted to a single twitter application.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">After all this I’d still believe that MEME still has a good chance to give Twitter a beat in its own game. The reason is simple. Yahoo! has multiple web-services which are used on a daily basis by a significantly large amount of web users. Yahoo! mail, it’s very popular Portal, Yahoo! Messenger may work as a great boon for its newly born service. Enabling usage of MEME from these services for eg: Sending a MEME through the Messenger status would be a great experience.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;"><img src="http://omkarkhair.co.cc/images/stories/yahoo_meme_100909 1.png" border="0" title="Yahoo! MEME home" /><br />While the MEME Sign-up procedure is still not online, you can send in your Email address to the service to receive an invite when Yahoo! is ready for you.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">I still haven’t got my MEME account, but I did browse for some people on MEME. Have a look.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;"><img src="http://omkarkhair.co.cc/images/stories/yahoo_meme_100909 2.png" border="0" title="Evan Williams on Yahoo! MEME" /></span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">For those who don’t know Evan Williams or EV. He is the CEO of Twitter. This might not be the real guy, but whoever created this profile has a good sense of humour 😛</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;"><img src="http://omkarkhair.co.cc/images/stories/yahoo_meme_100909.png" border="0" title="Jerry Yang on Yahoo! MEME" /></span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">Now this is Yahoo! co-founder Jerry Yang.</span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;"> </span>
</p>

<p style="margin-top: 10px; margin-bottom: 15px;">
  <span style="color: #000000;">Yahoo! MEME has a considerable chance to be a Twitter-Killer as quoted by ReadWriteWeb. It would be beneficial for Yahoo! in such a situation to release an API for developers to create Desktop application and external web services to interact with MEME. What’s the problem in going the Twitter style 😉</span>
</p>